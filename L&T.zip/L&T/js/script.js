// Hide and show between page_1 and page_2

$(document).ready(function(){
    $(".startClick").click(function(){
        $(".page_1").hide();
        $(".page_2").show();
        $("body").css({"background":"url(assets/images/Image2/bg.png)"});
    });
    $(".chapter_list_1").click(function(){
        $(".menu_content11").hide();
        $(".Module_overview").show();
        $(".Module_overview").css({"background":"white"});
    });
 });

//Play/Pause and Mute/UnMute button 
 
 function Playaudio(){
    var image1 = "assets/images/Image2/pause_button.png";
    var image2 = "assets/images/Image2/play_button.png"
    
    var toggleElement = document.getElementById('Playbtn');

    var image11 = "pause_button.png";
    var image22 = "play_button.png";
    var a = toggleElement.src.split('/');
    var b = a[a.length - 1];
    toggleElement.src = (b == image11)?image2:image1;
 }

 function Muteaudio(){
    var image1 = "assets/images/Image2/audio_button.png";
    var image2 = "assets/images/Image2/audio_button_hover.png";

    var toggleElement = document.getElementById('Mutebtn');

    var image11 = "audio_button.png";
    var image22 = "audio_button_hover.png";
    var a = toggleElement.src.split('/');
    var b = a[a.length - 1];
    if(b == image11){
        toggleElement.src=image2;
    }
    else{
        document.getElementById('Mutebtn').src=image1;
    }
 }

